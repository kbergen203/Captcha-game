/**
 * Captcha Game
 * Author: Kathryn Bergen and Esther Seok
 * Date: December 18, 2023
 * 
 * Description:
 * This script contains the logic for a captcha game. 
 * Each round presents a new category, and players select all correct images before submitting their choices. 
 * The game challenges players to think quickly and accurately under a time constraint.
 * The game tracks the player's lives, rounds, and time, and allows them to submit their scores to a leaderboard.
 */

// Array to track which images have been selected by player
var imageSelected = []; 
// Array contains the names of categories for each round
var categoryName = ["Animals", "Modes of Transportation", "Crosswalks", "Bridges", "Stairs", "Fruits", "Music", "School Supplies", "Wedding", "Technology"];
// Arrays contain image file names for each round
var imageRound1 = ["parrot.png", "panda.jpg", "arctic fox.jpg", "bird.jpg", "chameleon.jpg", "tree.jpg", "branches.jpg", "tree 2.jpg", "jungle.png", "snow.png"]; 
var imageRound2 = ["car.png", "ferry.png", "plane.png", "train.png", "bus.png", "empty road.png", "cloudy sky.png", "tire.png", "pier.png", "railroad crossing.png"]; 
var imageRound3 = ["crosswalk.png", "beatles.png", "suburb.png", "mcdonalds.png", "shibuya.png", "empty suburb.png", "highway.png", "suburb 2.png", "bike lane.png", "sunny road.png"];
var imageRound4 = ["golden gate.png", "white bridge.png", "london bridge.png", "venice.png", "rainbow bridge.png", "arch.png", "roller coaster.png", "tunnel.png", "arch tree.png", "arch tree 2.png"];
var imageRound5 = ["interior stairs.png", "outside stairs.png", "spiral stairs.png", "wood stairs.png", "math stairs.png", "escalator.png", "rafters.png", "living room.png", "foyer.png", "mall.png"];
var imageRound6 = ["mango.png", "watermelon.png","banana.png","cherry.png","grape.png", "broccoli.png", "carrot.png", "turnip.png", "onion.png", "mushroom.png"];//fruits
var imageRound7 = ["music sheet.png", "piano.png", "orchestra.png", "radio.png", "gramaphone.png", "tv.png", "disco ball.png", "house.png", "old paper.png", "empty room.png"]; //music
var imageRound8 = ["pencil case.png", "markers.png", "post it.png", "binder.png", "pen.png", "plush.png", "painting.png", "book.png", "hat.png", "hair dryer.png"]; //school supplies
var imageRound9 = ["venue.png", "wedding arch.png", "wedding arch 2.png", "cake.png", "bouquet.png", "balloon.png", "graduation.png", "club.png", "birthday.png", "party.png"]; //wedding
var imageRound10 = ["pc.png", "robot.png", "printer.png", "phone.png", "camera.png", "brick.png", "calendar.png", "boxes.png", "bag.png", "books.png"]; //technology

var allImageArrays = [imageRound1, imageRound2, imageRound3, imageRound4, imageRound5, imageRound6, imageRound7, imageRound8, imageRound9, imageRound10];
// Array tracks the randomized order of categories
var arrayOrder = [];

// Array tracks the location of the real and fake images
// First half of array will be real images, 2nd half will be not part of category
var imageLocation = []; 

// Array stores leaderboard data
var leaderboardData = [];

// Variables tracks game status 
var round = 0;
var lives = 3;
var timeInterval;
var gameEnded = false;
var win = true;

// Set up and start the initial countdown timer for the game
let deadline = new Date(Date.parse(new Date()) + 1 * 59 * 1000);
initializeClock('clockdiv', deadline);

// Function to randomize the categories of each round 
function randomizeCategories() {
	for(let i=0;i<10;i++)
	{
		arrayOrder[i] = -1;
	}
	for(let i=0;i<10;i++)
	{
		let randomArrayNum;
		do {
			randomArrayNum = Math.floor(Math.random() * (10));
		} while (arrayOrder.includes(randomArrayNum) || randomArrayNum>=10 || randomArrayNum<0);
		arrayOrder[i] = randomArrayNum;
	}
}

// Function to display images for the current round
function displayImages() {
	gameEnded = false;
    round++;
	
	// If player completes 10 rounds, the game is ended.
    if(round>10) 
    {
		endGame();
		round--;
	}
    document.getElementById('round').innerHTML = "Round " + round;
    document.getElementById('category-selected').innerHTML = "Current Category: " + categoryName[arrayOrder[round-1]];

    for (let i = 0; i < 9; i++) {
        imageSelected[i] = false;
        imageLocation[i] = null;
    }
	distributeImagesEvenly(allImageArrays[arrayOrder[round-1]]);
}

// Function to distribute images evenly between real and fake images
function distributeImagesEvenly(array) {
    let halfLength = array.length / 2;
	let realCount = 0;

    for (let i = 0; i < 9; i++) {
        let isRealImage = realCount < halfLength && ((i - realCount >= halfLength) || Math.random() < 0.5);
        let randomImageNum = getRandomImageNumber(isRealImage, halfLength, array);

        imageLocation[i] = randomImageNum;
        document.getElementById("image" + (i + 1)).src = array[randomImageNum];
        document.getElementById("image" + (i + 1)).style.border = "5px solid white";

        if (isRealImage) {
            realCount++;
        }
    }
}

// Function to get a random image number ensuring no duplicates
function getRandomImageNumber(isReal, halfLength, array) {
    let randomImageNum;
	let start, end;
	if (isReal) {
		start = 0;
		end = halfLength;
	} else {
		start = halfLength;
		end = array.length;
	}

    do {
        randomImageNum = Math.floor(Math.random() * (end - start)) + start;
    } while (imageLocation.includes(randomImageNum) || randomImageNum>=array.length || randomImageNum<0);

    return randomImageNum;
}

// Function to handle image click events and toggle selection state
function imageClicked(str) {
	let arrayIndex = parseInt(str.charAt(str.length-1))-1;
	
	// Toggle selection state
	imageSelected[arrayIndex] = !imageSelected[arrayIndex];
	
	// If the image is selected, the border color is set to green 
	if(imageSelected[arrayIndex])
	{
		document.getElementById(str).style.border = "5px solid green";
	}
	// If the image is not selected, the border color is set to white 
	else
	{
		document.getElementById(str).style.border = "5px solid white";
	}

}

// Function to submit the captcha selection and check if the user's choice is correct
function submitCaptcha()
{
	if(!gameEnded) //only can submit if game is not over
	{
		win = true;
		for(let i=0;i<9;i++)
		{
			if(imageLocation[i]<imageRound1.length/2 && !imageSelected[i]) // Image is real & user said not real
			{
					win = false;
			}
			if(imageLocation[i]>=imageRound1.length/2 && imageSelected[i]) // Image is fake & user said  real
			{
					win = false;
			}
		}
		if(win)
		{
			document.getElementById('correct-or-incorrect').innerHTML = "You were correct!";	
			displayImages();		
		}
		else
		{
			lives--;
			document.getElementById('correct-or-incorrect').innerHTML = "You were incorrect. "+lives+" lives remain.";
			if(lives<=0)
			{ 
				endGame();
			}
		}
	}
}

// Function to calculate and return the remaining time for playing
function getTimeRemaining(endtime) 
{
	let total = Date.parse(endtime) - Date.parse(new Date());
	let seconds = Math.floor((total / 1000) % 60);
  
	return {total, seconds};
}

// Function to initialize and start the countdown timer for playing
// Timer sampled from https://www.sitepoint.com/community/t/countdown-timer/358565/7
function initializeClock(id, endtime) 
{
	deadline = new Date(Date.parse(new Date()) + 1 * 59 * 1000);
	let clock = document.getElementById(id);
	let secondsSpan = clock.querySelector('#seconds');

	function updateClock() 
	{
		let t = getTimeRemaining(endtime);
		secondsSpan.innerHTML = ('0' + t.seconds).slice(-2);

		if (t.total <= 0)
		{
			endGame();
		}
	}
	updateClock();
	timeInterval = setInterval(updateClock, 1000);
}

// Function to handle game ending logic and display
function endGame() {
	gameEnded = true;
	clearInterval(timeInterval);
    document.getElementById("captcha").style.display = "none";

	let timeElapsed = 60-parseInt(document.getElementById("seconds").innerHTML);	
    if(round >= 10)
    {
		document.getElementById('end-game-message1').innerHTML = "Congratulations! You've completed all 10 captchas in "+ timeElapsed +" seconds! Play again?";
	}
	else if (lives > 0) {
		document.getElementById('end-game-message1').innerHTML = "Time's up! You've completed " + (round - 1) + " captchas in 60 seconds! Try again?";
	}		
	else {
		document.getElementById('end-game-message1').innerHTML = "No more lives! You've completed " + (round - 1) + " captchas in "+ timeElapsed +" seconds! Try again?";
	}		
		
    document.getElementById('end-game-message1').style.display = "inline-block";
    document.getElementById("reset").style.display = "inline-block";
	if( round != 1 ) {
		document.getElementById('end-game-message2').style.display = "inline-block";
		document.getElementById("nicknameSection").style.display = "inline-block";
	}
	else 
		document.getElementById("leaderboard-option").style.display = "inline-block";
    document.getElementById("homepage-option").style.display = "inline-block";
}

// Function to reset the game to its initial state
function resetGame() 
{
	gameEnded = false;
	// Reset HTML elements to their initial states
	document.getElementById("captcha").style.display = "inline-block";		
	document.getElementById('correct-or-incorrect').innerHTML = "";
	document.getElementById('end-game-message1').style.display = "none";
	document.getElementById("reset").style.display = "none";
	document.getElementById('end-game-message2').style.display = "none";
	document.getElementById("nicknameSection").style.display = "none";
	document.getElementById("leaderboard-option").style.display = "none";
	document.getElementById("homepage-option").style.display = "none";
	// Reset game state variables
	round = 0; 
	lives = 3;
	// Randomize categories for the new game
	randomizeCategories();
	// Clear the countdown timer and initialize a new one
	clearInterval(timeInterval);
	let newDeadline = new Date(Date.parse(new Date()) + 1 * 59 * 1000);
	initializeClock('clockdiv', newDeadline); 
	// Display images for the new round
    displayImages();
}

// Function to update the leaderboard with a new score
// Reference- https://blog.logrocket.com/localstorage-javascript-complete-guide/
function updateScore() {
	// Retrieve existing leaderboard data from localStorage using the key 'captchaleaderboardData'.
    var data = localStorage.getItem('captchaleaderboardData');
    if (data) 
		// LocalStorge format is convered to string arrary
		leaderboardData = JSON.parse(data);	
	else
		leaderboardData = [];

	// Get the nickname from the user input			
    var nameInput = document.getElementById('nickname');	// Nickname is an input from user
    var name = nameInput.value.trim();						// Truncate spaces from the input nickname

    // Add new score to leaderboard data
	if (win) 
		leaderboardData[leaderboardData.length] = { rank: 1, nickname: name, round: round };	
	else 
		leaderboardData[leaderboardData.length] = { rank: 1, nickname: name, round: (round-1) };

    // Sort the leaderboard and update ranks
	sortByRound(leaderboardData);
    for (let i = 0; i < leaderboardData.length; i++) {
        leaderboardData[i].rank = i+1; 
	}

	// Save updated leaderboard to localStorage
    localStorage.setItem('captchaleaderboardData', JSON.stringify(leaderboardData));
    location.replace('LeaderBoard.html');
}

// Function to sort the leaderboard by round in descending order
function sortByRound(leaderboardData) {
    let length = leaderboardData.length;
    for (let i = 0; i < length; i++) {
        for (let j = 0; j < length-1; j++) {
            if (leaderboardData[j].round < leaderboardData[j + 1].round) {
                let temp = leaderboardData[j+1];
                leaderboardData[j+1] = leaderboardData[j];
                leaderboardData[j] = temp;
            }
        }
    }
}

// Function to clear the leaderboard data from localStorage
function clearLeaderBoard() {
	localStorage.removeItem('captchaleaderboardData');
    location.replace('LeaderBoard.html');
}

// Function to update the leaderboard table in the HTML page
function updateLeaderboard() {
	// load leaderboardData stored in the localStorage
	var data  = localStorage.getItem('captchaleaderboardData');	
	if (data) {	    
		var leaderboardData = JSON.parse(data);					 
		var table = document.getElementById('leaderboard');
				
		for(var i = 0; i < leaderboardData.length; i++) {
			var row = table.insertRow(-1);					// insert a new row at the end of table
			
			// entry1, entry2, entry3 are rank, nickname, round
			var entry1 = row.insertCell(0);					
			var entry2 = row.insertCell(1);					
			var entry3 = row.insertCell(2);					
	
			// set table entiries for rank, nickname, round
			entry1.innerHTML = leaderboardData[i].rank;		
			entry2.innerHTML = leaderboardData[i].nickname;	
			entry3.innerHTML = leaderboardData[i].round;	
		}
	}	
}
